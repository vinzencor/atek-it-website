---
name: Quality & Data
order: 4
published: true
description: Quality assurance, testing, data analysis, and business intelligence roles
jobs:
  - data-analyst
  - qa-analyst
---

Quality & Data category covers all QA, testing, data analysis, and business intelligence positions.
