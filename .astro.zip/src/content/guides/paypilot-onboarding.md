---
title: "Pay Pilot Onboarding Workbook"
description: "Step-by-step planning sheet for new customers"
icon: "/images/guides/paypilot-icon.svg"
pdfFile: "/downloads/guides/paypilot-onboarding-workbook.pdf"
published: true
order: 4
date: "2024-01-30T00:00:00.000Z"
---

# Pay Pilot Onboarding Workbook

Complete step-by-step planning sheet and onboarding guide for new Pay Pilot customers.
